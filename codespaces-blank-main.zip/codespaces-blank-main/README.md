# Simple Web Calculator

Open `index.html` in your browser to use the calculator.

Files added:
- `index.html` — calculator UI
- `styles.css` — basic styling
- `script.js` — calculator logic (keyboard support included)

Quick open (from repo root):

```bash
# open in default browser (Linux desktop)
$BROWSER index.html

# or serve quickly with Python
python3 -m http.server 8000
# then open http://localhost:8000/index.html
```
