const display = document.getElementById('display');
let expr = '';

function updateDisplay(){
  display.textContent = expr || '0';
}

function safeEval(s){
  // Allow only digits, operators, decimal, parens and spaces
  if(!/^[0-9+\-*/().\s]+$/.test(s)) throw new Error('Invalid characters');
  // Evaluate safely using Function constructor in strict mode
  return Function('"use strict"; return (' + s + ')')();
}

function compute(){
  try{
    const result = safeEval(expr);
    expr = String(result);
    updateDisplay();
  }catch(e){
    display.textContent = 'Error';
    expr = '';
  }
}

document.querySelectorAll('.btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const v = btn.dataset.value;
    const action = btn.dataset.action;
    if(action === 'clear'){
      expr = '';
      updateDisplay();
    } else if(action === 'back'){
      expr = expr.slice(0, -1);
      updateDisplay();
    } else if(action === 'equals'){
      compute();
    } else if(v){
      expr += v;
      updateDisplay();
    }
  });
});

window.addEventListener('keydown', (e) => {
  if(/^[0-9]$/.test(e.key) || ['+','-','*','/','.', '(', ')'].includes(e.key)){
    expr += e.key;
    updateDisplay();
    e.preventDefault();
  } else if(e.key === 'Enter'){
    compute();
    e.preventDefault();
  } else if(e.key === 'Backspace'){
    expr = expr.slice(0, -1);
    updateDisplay();
    e.preventDefault();
  } else if(e.key.toLowerCase() === 'c'){
    expr = '';
    updateDisplay();
    e.preventDefault();
  }
});

updateDisplay();
